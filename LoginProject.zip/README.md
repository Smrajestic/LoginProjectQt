# LoginProjectQt
### [WIP]

Za uporabo na drugih racunalnikih se:

-spremeni Output .txt datotek (kamorkoli)

-izbri�e LoginProject.pro.user (ce ga ni, toliko bolje)
--se sam naredi, ko se program za�ene

-za zagon programa se klikne na LoginProject.pro

-za zagon se uporabi:
--"Qt Creator 3.3.0 (opensource)"
--"Based on Qt 5.4.0 (MSVC 2010, 32 bit)"